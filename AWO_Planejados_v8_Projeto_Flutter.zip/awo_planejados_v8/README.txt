AWO Planejados v8 Premium Online

Este pacote é o projeto Flutter inicial do aplicativo.

Para gerar APK sem Android Studio:
1. Envie este ZIP para um repositório no GitHub.
2. Acesse codemagic.io.
3. Conecte o GitHub.
4. Escolha o projeto Flutter.
5. Clique em Start build.
6. Baixe o APK gerado.

Recursos já desenhados:
- Tela inicial com logo/nome AWO Planejados
- Cadastro de clientes
- Orçamento
- Projetos com medidas
- Tela de IA Online
- Preparado para fotos, PDF, banco SQLite e internet
