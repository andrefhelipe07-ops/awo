import 'package:flutter/material.dart';

void main() => runApp(const AWOApp());

class AWOApp extends StatelessWidget {
  const AWOApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AWO Planejados',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B3D2E)),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [Dashboard(), Clientes(), Orcamentos(), Projetos(), IAOnline()];
  final titles = const ['Início', 'Clientes', 'Orçamentos', 'Projetos', 'IA Online'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(titles[index])),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Color(0xFF0B3D2E)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.chair_alt, color: Colors.white, size: 48),
                SizedBox(height: 12),
                Text('AWO Planejados', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                Text('Projetos sob medida com tecnologia', style: TextStyle(color: Colors.white70)),
              ]),
            ),
            menuItem(Icons.home, 'Início', 0),
            menuItem(Icons.people, 'Clientes', 1),
            menuItem(Icons.picture_as_pdf, 'Orçamentos', 2),
            menuItem(Icons.view_in_ar, 'Projetos', 3),
            menuItem(Icons.auto_awesome, 'IA Online', 4),
          ],
        ),
      ),
      body: pages[index],
    );
  }

  ListTile menuItem(IconData icon, String title, int i) => ListTile(
    leading: Icon(icon), title: Text(title), selected: index == i,
    onTap: () { setState(() => index = i); Navigator.pop(context); },
  );
}

class CardButton extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const CardButton(this.icon, this.title, this.subtitle, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.all(10), child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFF0B3D2E), child: Icon(icon, color: Colors.white)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.arrow_forward_ios),
    ),
  );
}

class Dashboard extends StatelessWidget { const Dashboard({super.key});
  @override Widget build(BuildContext context) => ListView(children: const [
    Padding(padding: EdgeInsets.all(18), child: Text('Sistema premium para marcenaria planejada.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
    CardButton(Icons.camera_alt, 'Foto do ambiente', 'Tire fotos e marque medidas do local'),
    CardButton(Icons.straighten, 'Medidas', 'Comprimento, altura, profundidade e observações'),
    CardButton(Icons.edit, 'Projetos editáveis', 'Monte e altere projetos de móveis'),
    CardButton(Icons.search, 'Preços online', 'Base preparada para buscar valores na internet'),
  ]);
}

class Clientes extends StatelessWidget { const Clientes({super.key});
  @override Widget build(BuildContext context) => FormPage(title: 'Cadastro de cliente', fields: const ['Nome do cliente', 'Telefone/WhatsApp', 'Endereço', 'Ambiente']);
}
class Orcamentos extends StatelessWidget { const Orcamentos({super.key});
  @override Widget build(BuildContext context) => FormPage(title: 'Novo orçamento', fields: const ['Cliente', 'Descrição do projeto', 'Valor dos materiais', 'Valor mão de obra', 'Prazo de entrega']);
}
class Projetos extends StatelessWidget { const Projetos({super.key});
  @override Widget build(BuildContext context) => FormPage(title: 'Montar projeto', fields: const ['Ambiente', 'Comprimento', 'Altura', 'Profundidade', 'Cor do MDF', 'Puxador', 'Observações']);
}
class IAOnline extends StatelessWidget { const IAOnline({super.key});
  @override Widget build(BuildContext context) => FormPage(title: 'Detalhar com IA', fields: const ['Descreva o móvel', 'Medidas gerais', 'Materiais desejados', 'Faixa de preço']);
}

class FormPage extends StatelessWidget {
  final String title; final List<String> fields; const FormPage({super.key, required this.title, required this.fields});
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16), children: [
      Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...fields.map((f) => Padding(padding: const EdgeInsets.only(bottom: 12), child: TextField(decoration: InputDecoration(labelText: f, border: const OutlineInputBorder())))),
      ElevatedButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Salvo na versão inicial'))), icon: const Icon(Icons.save), label: const Text('Salvar')),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.picture_as_pdf), label: const Text('Gerar PDF do orçamento')),
    ],
  );
}
